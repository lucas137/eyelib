var group__eyelib__screen =
[
    [ "ColorRGB", "structeye_1_1_color_r_g_b.html", [
      [ "b", "structeye_1_1_color_r_g_b.html#a0f142f6f02f3d91c8a7019a4014e2672", null ],
      [ "g", "structeye_1_1_color_r_g_b.html#a30a415f417ec25296e9e51a8e6c1fa43", null ],
      [ "r", "structeye_1_1_color_r_g_b.html#a6e994d9c82f62d25e8e1f2c4ae108425", null ]
    ] ],
    [ "PointXY", "structeye_1_1_point_x_y.html", [
      [ "x", "structeye_1_1_point_x_y.html#aee5e8e2116706d332cf2e015c0688cf6", null ],
      [ "y", "structeye_1_1_point_x_y.html#a80be643bc1e3a86939a5b6b3b5f70e1f", null ]
    ] ],
    [ "Screen", "structeye_1_1_screen.html", [
      [ "Screen", "structeye_1_1_screen.html#a1b8c96a714127a0d32cd2f0c077d7465", null ],
      [ "Screen", "structeye_1_1_screen.html#a58cdb9e9225cd167eea96fd55a0c27eb", null ],
      [ "operator!=", "group__eyelib__screen.html#ga1ea82e7d66d1e5dd4a4f88141d5d1516", null ],
      [ "operator<<", "group__eyelib__screen.html#ga8554938029e6a6ad886827042df29d3d", null ],
      [ "operator==", "group__eyelib__screen.html#ga98ab0e334c9377241a9defabf17b286a", null ],
      [ "screen", "group__eyelib__screen.html#ga600917db02495ba6ef213b84e9eec818", null ],
      [ "h_m", "structeye_1_1_screen.html#a6ce4592733055089e8f1b2b13ed4bc7b", null ],
      [ "h_px", "structeye_1_1_screen.html#ae4fcd5086f8d92f3279396a904024118", null ],
      [ "index", "structeye_1_1_screen.html#a7e536ffb2f289101a34cf97ccde3dedb", null ],
      [ "w_m", "structeye_1_1_screen.html#af0ca6b71147df74a989d9d3bebe5a16e", null ],
      [ "w_px", "structeye_1_1_screen.html#a258a24a9be03a5a9e61f4fb05bcc4870", null ],
      [ "x_px", "structeye_1_1_screen.html#aa04def098903d48ec961c4890e03ce24", null ],
      [ "y_px", "structeye_1_1_screen.html#ab9eb0dedef624106aa41a305ce99aae4", null ]
    ] ],
    [ "Target", "structeye_1_1_target.html", [
      [ "operator<<", "group__eyelib__screen.html#ga0fcdcbaf7ab72040bcc31e94e3456c43", null ],
      [ "target_array", "group__eyelib__screen.html#ga3ad7afc441e8db2d5dd2526aa1c46ed5", null ],
      [ "active", "structeye_1_1_target.html#a677848aac56bc18187cc5c6ada382973", null ],
      [ "x_px", "structeye_1_1_target.html#a450830c3ef13252447ffae42085fb669", null ],
      [ "y_px", "structeye_1_1_target.html#a92d3585cca0776a645b116282927170b", null ]
    ] ],
    [ "TargetDuration", "structeye_1_1_target_duration.html", [
      [ "active_ms", "structeye_1_1_target_duration.html#aa8abf0a562482fb9c0b3ebfef4689360", null ],
      [ "after_ms", "structeye_1_1_target_duration.html#a4bbb51c538ed6a336aaab641e85e6a77", null ],
      [ "before_ms", "structeye_1_1_target_duration.html#a8e24a0051a7d590ddf3bf60deb4706fe", null ]
    ] ],
    [ "Targets", "group__eyelib__screen.html#ga32cba8f93b5827151507033501e9be60", null ],
    [ "operator!=", "group__eyelib__screen.html#ga1ea82e7d66d1e5dd4a4f88141d5d1516", null ],
    [ "operator<<", "group__eyelib__screen.html#ga8554938029e6a6ad886827042df29d3d", null ],
    [ "operator<<", "group__eyelib__screen.html#ga0fcdcbaf7ab72040bcc31e94e3456c43", null ],
    [ "operator==", "group__eyelib__screen.html#ga98ab0e334c9377241a9defabf17b286a", null ],
    [ "screen", "group__eyelib__screen.html#ga600917db02495ba6ef213b84e9eec818", null ],
    [ "screen_list", "group__eyelib__screen.html#gadb16e1226d3c5dc908b95ba1bcb5ea2c", null ],
    [ "target_array", "group__eyelib__screen.html#ga3ad7afc441e8db2d5dd2526aa1c46ed5", null ],
    [ "target_array", "group__eyelib__screen.html#gaab68e4425de44433c38237e3ef43cbb1", null ]
];