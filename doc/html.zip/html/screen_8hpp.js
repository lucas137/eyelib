var screen_8hpp =
[
    [ "Targets", "screen_8hpp.html#ga32cba8f93b5827151507033501e9be60", null ],
    [ "screen_list", "screen_8hpp.html#gadb16e1226d3c5dc908b95ba1bcb5ea2c", null ],
    [ "target_array", "screen_8hpp.html#gaab68e4425de44433c38237e3ef43cbb1", null ]
];