var structeye_1_1window_1_1_gaze_widget =
[
    [ "GazeWidget", "structeye_1_1window_1_1_gaze_widget.html#a061b313d6735751dba9a5e1f36439d83", null ],
    [ "GazeWidget", "structeye_1_1window_1_1_gaze_widget.html#a6bfca364e121454956ad7017a20ba2c5", null ],
    [ "draw", "structeye_1_1window_1_1_gaze_widget.html#a9566da5c3c82ac4d197c7344c8d6f387", null ],
    [ "set", "structeye_1_1window_1_1_gaze_widget.html#a631af60664c165470576721da871a909", null ],
    [ "avg_x", "structeye_1_1window_1_1_gaze_widget.html#a397681da7ec37cc654f33dee3809cc24", null ],
    [ "avg_y", "structeye_1_1window_1_1_gaze_widget.html#a201aec41125bd2b0b701d0bdbe809fd2", null ],
    [ "fixation", "structeye_1_1window_1_1_gaze_widget.html#ab459b599d5fb4a278083016608bc347e", null ],
    [ "raw_x", "structeye_1_1window_1_1_gaze_widget.html#a1e478b129f2e82115859ff286cd24e55", null ],
    [ "raw_y", "structeye_1_1window_1_1_gaze_widget.html#aa348ad3f11c0d131ae10d9c23d80dc74", null ],
    [ "show_avg", "structeye_1_1window_1_1_gaze_widget.html#a99504b56beb22731a421950cc3b45d75", null ],
    [ "show_raw", "structeye_1_1window_1_1_gaze_widget.html#a1f51598124a1ae195742a6faf6a184dc", null ]
];