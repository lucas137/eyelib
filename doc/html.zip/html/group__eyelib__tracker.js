var group__eyelib__tracker =
[
    [ "State", "structeye_1_1_tracker_1_1_state.html", [
      [ "operator!=", "group__eyelib__tracker.html#ga025fc95f5bbafab0cd2b4ef58233bd5e", null ],
      [ "operator<<", "group__eyelib__tracker.html#ga8766ea8a7a586675dca5c908aaeba762", null ],
      [ "operator==", "group__eyelib__tracker.html#ga64b29f8b69a262482f12c93be6e1c45c", null ],
      [ "device_state", "structeye_1_1_tracker_1_1_state.html#a91b0772d5af6bbdbf4055e6dce3b1ab3", null ],
      [ "frame_rate", "structeye_1_1_tracker_1_1_state.html#a7cac030d6545bd04ad6fb3747408ad9f", null ],
      [ "is_calibrated", "structeye_1_1_tracker_1_1_state.html#a2a4e0a0ccc50b6bc600f0b6e32103e90", null ],
      [ "is_calibrating", "structeye_1_1_tracker_1_1_state.html#a8d389d181584af418566849e3884ff6a", null ],
      [ "is_connected", "structeye_1_1_tracker_1_1_state.html#a18b0708c51d916ec7224717d6d310023", null ],
      [ "is_started", "structeye_1_1_tracker_1_1_state.html#a4585cb805599f8350e42a321af4b093e", null ]
    ] ],
    [ "Tracker", "classeye_1_1_tracker.html", [
      [ "calib_handler", "classeye_1_1_tracker.html#a7a833c431bfa73e2dc534f24faa4e97e", null ],
      [ "gaze_handler", "classeye_1_1_tracker.html#a142d2f15a03e3eef0737ae42e22077f9", null ],
      [ "state_handler", "classeye_1_1_tracker.html#a0c404723d41e5bc1ccbce30a9333269d", null ],
      [ "Device", "classeye_1_1_tracker.html#ae7b2fc42cc84050396fdc44841142889", [
        [ "connected", "classeye_1_1_tracker.html#ae7b2fc42cc84050396fdc44841142889a06aa6fa8bdc2078e7e1bd903e70c8f6a", null ],
        [ "not_connected", "classeye_1_1_tracker.html#ae7b2fc42cc84050396fdc44841142889a69c2dbb5917ca550a862e9c1c839bca1", null ],
        [ "bad_firmware", "classeye_1_1_tracker.html#ae7b2fc42cc84050396fdc44841142889a2f91131e6b36ccda33ccc333cbaed9ee", null ],
        [ "no_usb_three", "classeye_1_1_tracker.html#ae7b2fc42cc84050396fdc44841142889ace0b7683764d9fe9b72647325570d7aa", null ],
        [ "no_stream", "classeye_1_1_tracker.html#ae7b2fc42cc84050396fdc44841142889a881999a844c0bb1ee62b8bd1b29e60bb", null ],
        [ "unrecognized", "classeye_1_1_tracker.html#ae7b2fc42cc84050396fdc44841142889a96d8e9e3b92248258403f7fc4cb25644", null ]
      ] ],
      [ "Tracker", "classeye_1_1_tracker.html#a011c836b33929bc61708858e66f98c99", null ],
      [ "~Tracker", "classeye_1_1_tracker.html#a3b59c32a574220f1c219b1f658f67547", null ],
      [ "Tracker", "classeye_1_1_tracker.html#afbbb737f694f7202247ef662072ac256", null ],
      [ "calibrate", "classeye_1_1_tracker.html#a537da68fc118823634c6aa286d6a9040", null ],
      [ "gaze_time_ms", "classeye_1_1_tracker.html#a764c40e2fd10ddbf592b4076cc6bcbec", null ],
      [ "get_calib_handler", "classeye_1_1_tracker.html#a5acfaf3c512544d2460ce29ce291118f", null ],
      [ "get_gaze_handler", "classeye_1_1_tracker.html#a50444c62371c3fc7bcd6e5a5563ca0d2", null ],
      [ "get_state_handler", "classeye_1_1_tracker.html#a8bbc56bb66084ebf348bdc0ef50f3eef", null ],
      [ "operator=", "classeye_1_1_tracker.html#af3f7ca84e14b80146a5497a7d072c583", null ],
      [ "register_handler", "classeye_1_1_tracker.html#ae2620ccceb0fb471c0f8778fe75d1cb7", null ],
      [ "register_handler", "classeye_1_1_tracker.html#a5444ab7d72cb349468509a145d1d89d3", null ],
      [ "register_handler", "classeye_1_1_tracker.html#ae2731146a5c632bc860949cad94bbb46", null ],
      [ "start", "classeye_1_1_tracker.html#a56f1fc53917db85584a9d6ffeb83aa2f", null ],
      [ "state", "classeye_1_1_tracker.html#ad18cf966cf51407d2b0f8f0a2cd61a2d", null ],
      [ "target", "classeye_1_1_tracker.html#a11f8a3175800538437a8a9398b770877", null ],
      [ "window", "classeye_1_1_tracker.html#ac4ed9e28b03dcc1192dd1abd4acfcb87", null ],
      [ "window", "classeye_1_1_tracker.html#a32954cabfc49d1e153b4adf1ad01c210", null ],
      [ "operator<<", "group__eyelib__tracker.html#gadd1fe3a6021f61551d886b3f278838d3", null ]
    ] ],
    [ "operator!=", "group__eyelib__tracker.html#ga025fc95f5bbafab0cd2b4ef58233bd5e", null ],
    [ "operator<<", "group__eyelib__tracker.html#gadd1fe3a6021f61551d886b3f278838d3", null ],
    [ "operator<<", "group__eyelib__tracker.html#ga8766ea8a7a586675dca5c908aaeba762", null ],
    [ "operator==", "group__eyelib__tracker.html#ga64b29f8b69a262482f12c93be6e1c45c", null ],
    [ "to_number", "group__eyelib__tracker.html#ga06f90da269110746a3740ab3e0569b81", null ],
    [ "to_string", "group__eyelib__tracker.html#ga395b7672bcf50798c44276c518de9db3", null ],
    [ "tracker_device_state", "group__eyelib__tracker.html#ga7fe1e988a67ccce93b80bfb3d14888d1", null ]
];