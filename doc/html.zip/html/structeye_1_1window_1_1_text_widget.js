var structeye_1_1window_1_1_text_widget =
[
    [ "TextWidget", "structeye_1_1window_1_1_text_widget.html#aae8c43d0b5d50565cd93533ea651a40e", null ],
    [ "TextWidget", "structeye_1_1window_1_1_text_widget.html#a434d4ae424c69f8f574340abb208b125", null ],
    [ "draw", "structeye_1_1window_1_1_text_widget.html#ab216ae118ba95b69c09ee04b71c478e9", null ],
    [ "show", "structeye_1_1window_1_1_text_widget.html#ab73a43295ff4a1ba2480d99c922eda7e", null ]
];