var modules =
[
    [ "eyelib", "group__eyelib.html", "group__eyelib" ],
    [ "Eyelib_datalog", "group__eyelib__datalog.html", "group__eyelib__datalog" ],
    [ "Eyelib_message", "group__eyelib__message.html", "group__eyelib__message" ],
    [ "Window Events", "group__event.html", "group__event" ],
    [ "Window Gaze Point", "group__text.html", "group__text" ],
    [ "Eyelib_window", "group__eyelib__window.html", "group__eyelib__window" ]
];