var group__eyelib__gaze =
[
    [ "DispersionThreshold", "classeye_1_1_dispersion_threshold.html", [
      [ "DispersionThreshold", "classeye_1_1_dispersion_threshold.html#afb0fc0dd10efe1dbb3afa83033ee3a80", null ],
      [ "centroid", "classeye_1_1_dispersion_threshold.html#af1e8925905ae23911f352cf79f287e1d", null ],
      [ "dispersion", "classeye_1_1_dispersion_threshold.html#af42558ccd8cef1091a6ba936d03df069", null ],
      [ "fixation", "classeye_1_1_dispersion_threshold.html#a44aabdc2460396be7c0783b65fc5a6e0", null ]
    ] ],
    [ "Fixation", "classeye_1_1_fixation.html", [
      [ "Fixation", "classeye_1_1_fixation.html#a40ad0e1ed7e8089d7761b374e3aec33e", null ],
      [ "count", "classeye_1_1_fixation.html#ad493813bab2e030fe7a0cc32b92c83e4", null ],
      [ "duration", "classeye_1_1_fixation.html#abe8f0df9eaf034b7429b6df54d5c4514", null ],
      [ "gaze", "classeye_1_1_fixation.html#a0cf123f4dd97a26799b27c70608b47ae", null ],
      [ "interval", "classeye_1_1_fixation.html#a3effd15a0def8a958ac048544bdad36b", null ],
      [ "is_fixated", "classeye_1_1_fixation.html#a96b5dcb24505b6b5d2ea88d4c5fc15c5", null ],
      [ "position", "classeye_1_1_fixation.html#a70d5bcf2d12544e3ea13d0db4fdd6937", null ],
      [ "x", "classeye_1_1_fixation.html#a075562a38fa1a48041030dfd34405407", null ],
      [ "y", "classeye_1_1_fixation.html#a33ffe107436c76edf836481218874308", null ]
    ] ],
    [ "TimeMetrics", "classeye_1_1_time_metrics.html", [
      [ "duration_values", "classeye_1_1_time_metrics.html#ac2435365e51f92c0b7d373f44b66233b", null ],
      [ "interval_values", "classeye_1_1_time_metrics.html#a7e67d982bc0ae9d78ccbb7a30b7e1b56", null ],
      [ "duration", "classeye_1_1_time_metrics.html#ae8a751a21f5ed350462fb78168e8e4a3", null ],
      [ "interval", "classeye_1_1_time_metrics.html#afb2742663a9a898d53035ca1ac06aef5", null ],
      [ "update", "classeye_1_1_time_metrics.html#a8b6538514029c223a5345e8a3eeba0b0", null ]
    ] ],
    [ "SaccadeDistance", "classeye_1_1_saccade_distance.html", [
      [ "distance_values", "classeye_1_1_saccade_distance.html#a1a4ddac7e3b109f3916feb32e4c481e7", null ],
      [ "distance_sq", "classeye_1_1_saccade_distance.html#af8fd94752c83b1a34eadcfe214c20192", null ],
      [ "update", "classeye_1_1_saccade_distance.html#aba0010d7bb6187d1f848cb5e75cc29ca", null ]
    ] ],
    [ "Pupillometry", "classeye_1_1_pupillometry.html", [
      [ "size_values", "classeye_1_1_pupillometry.html#a10e415473d9964306b94031283bacee4", null ],
      [ "pupil_size", "classeye_1_1_pupillometry.html#ab703a19ec3f1c6734cf45b55a2c8d94b", null ],
      [ "update", "classeye_1_1_pupillometry.html#a306e2b9a46919d9cf090f473aaf258d6", null ]
    ] ],
    [ "PointCluster", "classeye_1_1_point_cluster.html", [
      [ "clear", "classeye_1_1_point_cluster.html#accc78f1964aae0d3ce1440fc7c35a0e7", null ],
      [ "duration", "classeye_1_1_point_cluster.html#adcd00e0489270604441eb8e543b52f4b", null ],
      [ "empty", "classeye_1_1_point_cluster.html#a9d258c5cd516d38f831207668d8d344a", null ],
      [ "mean_x", "classeye_1_1_point_cluster.html#abb6f4189f93cd85922be85c1efbcbb50", null ],
      [ "mean_y", "classeye_1_1_point_cluster.html#ad9874b62ce67e10aea4c2d07ac074fcd", null ],
      [ "pop_front", "classeye_1_1_point_cluster.html#a43229856c305cfdce0be58443fa9c7fd", null ],
      [ "push_back", "classeye_1_1_point_cluster.html#a1c5573cdceeded5890d02daf3fbe2b7f", null ],
      [ "size", "classeye_1_1_point_cluster.html#a3f8e1a08dfc341eb5a475f3dd5560c05", null ],
      [ "start", "classeye_1_1_point_cluster.html#a7a4a25823b949d7317afc914da747f1c", null ]
    ] ],
    [ "VelocityThreshold", "classeye_1_1_velocity_threshold.html", [
      [ "VelocityThreshold", "classeye_1_1_velocity_threshold.html#ad455bd18ae3fb34ba561898060f18c8c", null ],
      [ "centroid", "classeye_1_1_velocity_threshold.html#a1608f55206bd08ca5e21bcd51ac5a564", null ],
      [ "displacement", "classeye_1_1_velocity_threshold.html#a64ccc8946c80d9e5e441b3bd00c698f3", null ],
      [ "fixation", "classeye_1_1_velocity_threshold.html#a31f7d001954004ef27df3c02b666bee2", null ]
    ] ],
    [ "Pupil", "structeye_1_1_gaze_1_1_pupil.html", [
      [ "Pupil", "structeye_1_1_gaze_1_1_pupil.html#a8b5f433224cc700955a0ed56bef5ac81", null ],
      [ "Pupil", "structeye_1_1_gaze_1_1_pupil.html#acd99f1a722bc8135e2575aa63c42dfda", null ],
      [ "center", "structeye_1_1_gaze_1_1_pupil.html#a0c45dcc8053ae5447695eda4159646a5", null ],
      [ "size", "structeye_1_1_gaze_1_1_pupil.html#a5d8a9670b875b4f0de4558b7c1a11011", null ]
    ] ],
    [ "Tracking", "structeye_1_1_gaze_1_1_tracking.html", [
      [ "Tracking", "structeye_1_1_gaze_1_1_tracking.html#ac3788474c3ee981a7d243cfc2675b8e5", null ],
      [ "Tracking", "structeye_1_1_gaze_1_1_tracking.html#a397b3a681ea35a5edb6ebd16dd5168d3", null ],
      [ "Tracking", "structeye_1_1_gaze_1_1_tracking.html#aed21b15b5423d5f637a0df272d5b8573", null ],
      [ "operator<<", "group__eyelib__gaze.html#ga3ac70f2d98dcdae96083e0a3320c1987", null ],
      [ "to_string", "group__eyelib__gaze.html#gadea9113518a4fdf0bcd2fa4342838f02", null ],
      [ "bits", "structeye_1_1_gaze_1_1_tracking.html#ace3a372f1c8bef39985abbf3ab0e6c37", null ],
      [ "eyes", "structeye_1_1_gaze_1_1_tracking.html#a46910d948818b12e129221ebfb8e8dd6", null ],
      [ "fail", "structeye_1_1_gaze_1_1_tracking.html#ae518369aa1bc0e7a51f2a33766c30ccb", null ],
      [ "gaze", "structeye_1_1_gaze_1_1_tracking.html#af44c0884c0f30272efa4af78dfff80a0", null ],
      [ "lost", "structeye_1_1_gaze_1_1_tracking.html#a94ee8b52801c20fe773f109f3e953fe3", null ],
      [ "user", "structeye_1_1_gaze_1_1_tracking.html#a89dfbae3234b9e34bf00d34979de582f", null ]
    ] ],
    [ "Gaze", "structeye_1_1_gaze.html", [
      [ "Gaze", "structeye_1_1_gaze.html#ac6da332904a2dec1316d67a5e8d77e28", null ],
      [ "Gaze", "structeye_1_1_gaze.html#a4eb5193b857e3e2a4b1035b2c3dca560", null ],
      [ "csv_header", "group__eyelib__gaze.html#ga1cb8ef0b9f8880cf4a4622573e2a8475", null ],
      [ "operator<<", "group__eyelib__gaze.html#ga726a8bdb97cb306c8f0d33517cc726cf", null ],
      [ "avg_px", "structeye_1_1_gaze.html#aad6e7b9af8c74166970c9ac5839e8838", null ],
      [ "fixation", "structeye_1_1_gaze.html#a5252e06be034a0c671456734852eea26", null ],
      [ "pupil_left", "structeye_1_1_gaze.html#ad3e4c98186b98b0dd5b55c4948f283b0", null ],
      [ "pupil_right", "structeye_1_1_gaze.html#ac43704ddf9205ee8e22df50945a7b0d9", null ],
      [ "raw_px", "structeye_1_1_gaze.html#af7b8b760c402ed3a28f15fe54ed39d74", null ],
      [ "time_ms", "structeye_1_1_gaze.html#a0a075aa84120ec4e2ae7c795e14fb94e", null ],
      [ "timestamp", "structeye_1_1_gaze.html#a65fdb9b004df75d33a79e725867abb6e", null ],
      [ "tracking", "structeye_1_1_gaze.html#affa5fef8ce218f05ed262f6c8a846845", null ]
    ] ],
    [ "BlinkTime", "group__eyelib__gaze.html#gab62d15adde0465d49d41215972970656", null ],
    [ "FixationTime", "group__eyelib__gaze.html#gad98df527ad601931f9b5e84577001eab", null ],
    [ "csv", "group__eyelib__gaze.html#ga03097eaa6bca4a00228999e5b74b70f8", null ],
    [ "csv", "group__eyelib__gaze.html#gabe1400613d84cedc760f7b89c7f0cad9", null ],
    [ "csv_header", "group__eyelib__gaze.html#ga1cb8ef0b9f8880cf4a4622573e2a8475", null ],
    [ "csv_header< Gaze::Tracking >", "group__eyelib__gaze.html#ga3d90f6d6f4f8db38d7bb763a3dd0cb88", null ],
    [ "operator<<", "group__eyelib__gaze.html#ga3ac70f2d98dcdae96083e0a3320c1987", null ],
    [ "operator<<", "group__eyelib__gaze.html#ga726a8bdb97cb306c8f0d33517cc726cf", null ],
    [ "to_string", "group__eyelib__gaze.html#gadea9113518a4fdf0bcd2fa4342838f02", null ]
];