var metrics_8hpp =
[
    [ "BlinkTime", "metrics_8hpp.html#gab62d15adde0465d49d41215972970656", null ],
    [ "FixationTime", "metrics_8hpp.html#gad98df527ad601931f9b5e84577001eab", null ]
];