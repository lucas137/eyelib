var calib__rating_8hpp =
[
    [ "calib_rating", "calib__rating_8hpp.html#af3f1fb6202db327ea6b9b5817e9bd43a", null ],
    [ "calib_rating", "calib__rating_8hpp.html#ab5456cf2e629e0a60d8dd5860ac0284d", null ],
    [ "calib_rating_num", "calib__rating_8hpp.html#afee6e4166422d563ae9964792f4bb8d6", null ],
    [ "calib_rating_str", "calib__rating_8hpp.html#a49803617bf806ee380295a3f9aa054a9", null ],
    [ "operator<<", "calib__rating_8hpp.html#a41b6d751808f368116fcb679f8fe1f2d", null ],
    [ "to_string", "calib__rating_8hpp.html#a0bf17311a3e9e2ef0be6ac579f07ce8d", null ],
    [ "error_deg_good", "calib__rating_8hpp.html#a02f3a8aac95fea74d76a894261179605", null ],
    [ "error_deg_great", "calib__rating_8hpp.html#ac61823558c02ad38907bdd1debfcc974", null ],
    [ "error_deg_moderate", "calib__rating_8hpp.html#a3fbdb452d47d103dcc39835ef0e9004b", null ],
    [ "error_deg_poor", "calib__rating_8hpp.html#a5e21785a01dd76ac8f161e60b25c4881", null ]
];