var files =
[
    [ "calib_eyes.hpp", "calib__eyes_8hpp.html", "calib__eyes_8hpp" ],
    [ "calib_point.hpp", "calib__point_8hpp.html", "calib__point_8hpp" ],
    [ "calib_rating.hpp", "calib__rating_8hpp.html", "calib__rating_8hpp" ],
    [ "calib_widget.hpp", "calib__widget_8hpp.html", "calib__widget_8hpp" ],
    [ "calibration.hpp", "calibration_8hpp.html", null ],
    [ "calibrator.hpp", "calibrator_8hpp.html", [
      [ "Calibrator", "classeye_1_1tracker_1_1_calibrator.html", "classeye_1_1tracker_1_1_calibrator" ]
    ] ],
    [ "datalog.hpp", "datalog_8hpp.html", null ],
    [ "debug_out.hpp", "debug__out_8hpp.html", "debug__out_8hpp" ],
    [ "dispersion_threshold.hpp", "dispersion__threshold_8hpp.html", null ],
    [ "event.hpp", "event_8hpp.html", null ],
    [ "eyelib.hpp", "eyelib_8hpp.html", "eyelib_8hpp" ],
    [ "fixation.hpp", "fixation_8hpp.html", null ],
    [ "gaze.hpp", "gaze_8hpp.html", "gaze_8hpp" ],
    [ "gaze_target.hpp", "gaze__target_8hpp.html", [
      [ "GazeTarget", "classeye_1_1_gaze_target.html", "classeye_1_1_gaze_target" ]
    ] ],
    [ "gaze_widget.hpp", "gaze__widget_8hpp.html", null ],
    [ "message.hpp", "message_8hpp.html", "message_8hpp" ],
    [ "metrics.hpp", "metrics_8hpp.html", "metrics_8hpp" ],
    [ "point_cluster.hpp", "point__cluster_8hpp.html", null ],
    [ "screen.hpp", "screen_8hpp.html", "screen_8hpp" ],
    [ "target_widget.hpp", "target__widget_8hpp.html", "target__widget_8hpp" ],
    [ "text_widget.hpp", "text__widget_8hpp.html", null ],
    [ "tracker.hpp", "tracker_8hpp.html", "tracker_8hpp" ],
    [ "velocity_threshold.hpp", "velocity__threshold_8hpp.html", null ],
    [ "window.hpp", "window_8hpp.html", "window_8hpp" ]
];