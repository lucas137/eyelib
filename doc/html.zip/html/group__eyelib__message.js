var group__eyelib__message =
[
    [ "Value", "structeye_1_1tracker_1_1_message_1_1_value.html", null ],
    [ "Message", "classeye_1_1tracker_1_1_message.html", [
      [ "Category", "classeye_1_1tracker_1_1_message.html#a210d62aebe668008d620bea0c4ccc222", [
        [ "tracker", "classeye_1_1tracker_1_1_message.html#a210d62aebe668008d620bea0c4ccc222aae2aeb935c2a8c7a80fb116093ef35ca", null ],
        [ "calibration", "classeye_1_1tracker_1_1_message.html#a210d62aebe668008d620bea0c4ccc222a0bf719dffe05883fa29d1685db040cad", null ],
        [ "heartbeat", "classeye_1_1tracker_1_1_message.html#a210d62aebe668008d620bea0c4ccc222a3a06e053a0726537b202ce4ace81dee7", null ],
        [ "unknown", "classeye_1_1tracker_1_1_message.html#a210d62aebe668008d620bea0c4ccc222aad921d60486366258809553a3db49a4a", null ]
      ] ],
      [ "Request", "classeye_1_1tracker_1_1_message.html#a60f7ab2615b2a55b8c8c5a7469c1b7f7", [
        [ "get", "classeye_1_1tracker_1_1_message.html#a60f7ab2615b2a55b8c8c5a7469c1b7f7ab5eda0a74558a342cf659187f06f746f", null ],
        [ "set", "classeye_1_1tracker_1_1_message.html#a60f7ab2615b2a55b8c8c5a7469c1b7f7acdaeeeba9b4a4c5ebf042c0215a7bb0e", null ],
        [ "start", "classeye_1_1tracker_1_1_message.html#a60f7ab2615b2a55b8c8c5a7469c1b7f7aea2b2676c28c0db26d39331a336c6b92", null ],
        [ "point_start", "classeye_1_1tracker_1_1_message.html#a60f7ab2615b2a55b8c8c5a7469c1b7f7ac0b3630cfc0f169134c1128fcc4d8b4e", null ],
        [ "point_end", "classeye_1_1tracker_1_1_message.html#a60f7ab2615b2a55b8c8c5a7469c1b7f7a56d7da393733a3dc41346d0b736e66f9", null ],
        [ "abort", "classeye_1_1tracker_1_1_message.html#a60f7ab2615b2a55b8c8c5a7469c1b7f7a5bb94a1c12413a2e5d14deabab29f2aa", null ],
        [ "clear", "classeye_1_1tracker_1_1_message.html#a60f7ab2615b2a55b8c8c5a7469c1b7f7a01bc6f8efa4202821e95f4fdf6298b30", null ],
        [ "unknown", "classeye_1_1tracker_1_1_message.html#a60f7ab2615b2a55b8c8c5a7469c1b7f7aad921d60486366258809553a3db49a4a", null ]
      ] ],
      [ "Status", "classeye_1_1tracker_1_1_message.html#ac0bf852b46252097390ae43e12f0e703", [
        [ "unknown", "classeye_1_1tracker_1_1_message.html#ac0bf852b46252097390ae43e12f0e703aad921d60486366258809553a3db49a4a", null ],
        [ "ok", "classeye_1_1tracker_1_1_message.html#ac0bf852b46252097390ae43e12f0e703a444bcb3a3fcf8389296c49467f27e1d6", null ],
        [ "bad_request", "classeye_1_1tracker_1_1_message.html#ac0bf852b46252097390ae43e12f0e703a373d9e6e1aaf30e691dadb57eb22d7b1", null ],
        [ "server_error", "classeye_1_1tracker_1_1_message.html#ac0bf852b46252097390ae43e12f0e703a0317120d5eccfe09a241439b7dc3af2c", null ],
        [ "calib_change", "classeye_1_1tracker_1_1_message.html#ac0bf852b46252097390ae43e12f0e703af4007d16ae41cf6274ed12695c210c07", null ],
        [ "screen_change", "classeye_1_1tracker_1_1_message.html#ac0bf852b46252097390ae43e12f0e703a57ab9f776a02e806f43e6422b3d99f8b", null ],
        [ "device_change", "classeye_1_1tracker_1_1_message.html#ac0bf852b46252097390ae43e12f0e703a82ba378b7c66a36259954bd9794484f8", null ]
      ] ],
      [ "has_value", "classeye_1_1tracker_1_1_message.html#af4d933067789feb83c303bed23531b74", null ],
      [ "category", "classeye_1_1tracker_1_1_message.html#ab40628e1e8f5eeec3cc53a2fec8f005c", null ],
      [ "json", "classeye_1_1tracker_1_1_message.html#ace7c91a81a7ff03c437f67bdc76a5293", null ],
      [ "request", "classeye_1_1tracker_1_1_message.html#a39713e53515b582d3103f5d1a18b4ddd", null ],
      [ "status", "classeye_1_1tracker_1_1_message.html#a9d1ed980769493fcf485515037e24df5", null ],
      [ "values", "classeye_1_1tracker_1_1_message.html#a836faf9392e261f1f5edb493cebd9586", null ]
    ] ],
    [ "category", "group__eyelib__message.html#ga4bfe9ce707806394a8517c2abbadfe15", null ],
    [ "operator<<", "group__eyelib__message.html#ga92f79398babe7d9ad3996df09713e187", null ],
    [ "operator<<", "group__eyelib__message.html#gafa6b47e956e9c7cd43bc40f323506acf", null ],
    [ "operator<<", "group__eyelib__message.html#gae4d4843722ff5f360354703e78a375b5", null ],
    [ "request", "group__eyelib__message.html#ga58676aed615d5246855bb3c382eb8df8", null ],
    [ "status", "group__eyelib__message.html#gad0c12436c81e9c229e7bcd2d3801cf51", null ],
    [ "to_number", "group__eyelib__message.html#ga58d301eef6f3ef46c6ad95512631c3bb", null ],
    [ "to_string", "group__eyelib__message.html#gaeaa4b1474f5adfb9386398b6b6d50217", null ],
    [ "to_string", "group__eyelib__message.html#ga327a63b426161fa6449ee0c6ffd1fd8c", null ],
    [ "to_string", "group__eyelib__message.html#ga8809701b6e47e1c319ab4030c9c49862", null ]
];