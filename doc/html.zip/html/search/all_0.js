var searchData=
[
  ['accuracy_5fdeg',['accuracy_deg',['../structeye_1_1_calibration_1_1_point.html#a05bb3cde2d67cb8d87c914557751698f',1,'eye::Calibration::Point']]],
  ['accuracy_5frating',['accuracy_rating',['../structeye_1_1_calibration_1_1_point.html#a4176cae0cacc8e8026d40c72f60e5d3c',1,'eye::Calibration::Point']]],
  ['active',['active',['../structeye_1_1_target.html#a677848aac56bc18187cc5c6ada382973',1,'eye::Target::active()'],['../structeye_1_1window_1_1_target_widget.html#a795ccf60ce6228530053a2309a938970',1,'eye::window::TargetWidget::active()'],['../classeye_1_1_window.html#ac15c67a5c5ce34b23c6aad3c0e63a4f4ac76a5e84e4bdee527e274ea30c680d79',1,'eye::Window::active()']]],
  ['active_5fms',['active_ms',['../structeye_1_1_target_duration.html#aa8abf0a562482fb9c0b3ebfef4689360',1,'eye::TargetDuration']]],
  ['advance',['advance',['../classeye_1_1_gaze_target.html#a22bc078588a0fdcf194ed5a09b52e55d',1,'eye::GazeTarget::advance(handler callback)'],['../classeye_1_1_gaze_target.html#a6530d0e2feda77e3d24972c86a1edf2f',1,'eye::GazeTarget::advance()']]],
  ['after_5fms',['after_ms',['../structeye_1_1_target_duration.html#a4bbb51c538ed6a336aaab641e85e6a77',1,'eye::TargetDuration']]],
  ['alt',['alt',['../structeye_1_1window_1_1_event_1_1_state_1_1_key.html#a957d1c9f283bbb910d24ea43c4d76553',1,'eye::window::Event::State::Key']]],
  ['alt_5fleft',['alt_left',['../structeye_1_1window_1_1_event_1_1_key.html#a13d3516e24998563c23a78fd03b7607ca87ef7ffb504eaa5c7307a8a739974767',1,'eye::window::Event::Key']]],
  ['alt_5fright',['alt_right',['../structeye_1_1window_1_1_event_1_1_key.html#a13d3516e24998563c23a78fd03b7607ca66c27042ffabee2b8d1c35e64fd0dc16',1,'eye::window::Event::Key']]],
  ['avg_5fpx',['avg_px',['../structeye_1_1_gaze.html#aad6e7b9af8c74166970c9ac5839e8838',1,'eye::Gaze']]],
  ['avg_5fstd_5fdev_5fpx',['avg_std_dev_px',['../structeye_1_1_calibration_1_1_point.html#a21f6d0d8a0f36bae8d332bf59109c74f',1,'eye::Calibration::Point']]],
  ['avg_5fx',['avg_x',['../structeye_1_1window_1_1_gaze_widget.html#a397681da7ec37cc654f33dee3809cc24',1,'eye::window::GazeWidget']]],
  ['avg_5fy',['avg_y',['../structeye_1_1window_1_1_gaze_widget.html#a201aec41125bd2b0b701d0bdbe809fd2',1,'eye::window::GazeWidget']]]
];
