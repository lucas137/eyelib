var searchData=
[
  ['screen',['Screen',['../structeye_1_1_screen.html#a1b8c96a714127a0d32cd2f0c077d7465',1,'eye::Screen::Screen(unsigned index, int x_px, int y_px, unsigned w_px, unsigned h_px, float w_m, float h_m)'],['../structeye_1_1_screen.html#a58cdb9e9225cd167eea96fd55a0c27eb',1,'eye::Screen::Screen()=default'],['../group__eyelib__screen.html#ga600917db02495ba6ef213b84e9eec818',1,'eye::Screen::screen(unsigned index=0)']]],
  ['screen_5flist',['screen_list',['../group__eyelib__screen.html#gadb16e1226d3c5dc908b95ba1bcb5ea2c',1,'eye']]],
  ['scroll_5fdx',['scroll_dx',['../structeye_1_1window_1_1_event_1_1_state_1_1_mouse.html#a9469764e1cd35755ff6d0054499282e8',1,'eye::window::Event::State::Mouse']]],
  ['scroll_5fdy',['scroll_dy',['../structeye_1_1window_1_1_event_1_1_state_1_1_mouse.html#a96965bd9de386f02518fdb4f532dfd98',1,'eye::window::Event::State::Mouse']]],
  ['scroll_5flock',['scroll_lock',['../structeye_1_1window_1_1_event_1_1_state_1_1_key.html#a7dd012c33d8b2c39f792fc0327db48f3',1,'eye::window::Event::State::Key']]],
  ['set',['set',['../classeye_1_1window_1_1_calib_widget.html#a6eb92abc03ed4dd790e653ec0acef3df',1,'eye::window::CalibWidget::set()'],['../structeye_1_1window_1_1_gaze_widget.html#a631af60664c165470576721da871a909',1,'eye::window::GazeWidget::set()'],['../classeye_1_1_window.html#aaecd8fd3c354ffdc6af2417e8f53df99',1,'eye::Window::set(Target const &amp;t)'],['../classeye_1_1_window.html#af220d1af05617badac386946531b6552',1,'eye::Window::set(Targets const &amp;ts)']]],
  ['set_5ftargets',['set_targets',['../classeye_1_1_gaze_target.html#a44cfe0a2dcc663e763354d05ae5656fa',1,'eye::GazeTarget']]],
  ['shift',['shift',['../structeye_1_1window_1_1_event_1_1_state_1_1_key.html#a5ea1b2950a19347fde7ea28453000c78',1,'eye::window::Event::State::Key']]],
  ['show',['show',['../classeye_1_1window_1_1_calib_widget.html#aaf69ad3784c67184d87a824fbc178b47',1,'eye::window::CalibWidget::show() const '],['../classeye_1_1window_1_1_calib_widget.html#a91a379c0a33edc81c937cf133d89e5cb',1,'eye::window::CalibWidget::show(Show const &amp;s)']]],
  ['show_5favg_5fgaze',['show_avg_gaze',['../classeye_1_1_window.html#aa6d588968d3a320de47f259ce61958b1',1,'eye::Window']]],
  ['show_5fraw_5fgaze',['show_raw_gaze',['../classeye_1_1_window.html#a96a65d261a252b81055f12a608e5b240',1,'eye::Window']]],
  ['size',['size',['../classeye_1_1_point_cluster.html#a3f8e1a08dfc341eb5a475f3dd5560c05',1,'eye::PointCluster']]],
  ['special',['special',['../structeye_1_1window_1_1_event_1_1_key.html#ad95cd7764d9f7aad04ce9acd33b112a3',1,'eye::window::Event::Key']]],
  ['start',['start',['../classeye_1_1_point_cluster.html#a7a4a25823b949d7317afc914da747f1c',1,'eye::PointCluster::start()'],['../classeye_1_1_tracker.html#a56f1fc53917db85584a9d6ffeb83aa2f',1,'eye::Tracker::start()'],['../classeye_1_1_gaze_target.html#a6eb03ac7e0ede7b1a8b2cb8b47edfbec',1,'eye::GazeTarget::start(handler callback)'],['../classeye_1_1_gaze_target.html#a1a9dee4965bac9596cf8c60a04ffbcdd',1,'eye::GazeTarget::start()']]],
  ['state',['state',['../classeye_1_1_tracker.html#ad18cf966cf51407d2b0f8f0a2cd61a2d',1,'eye::Tracker']]],
  ['status',['status',['../group__eyelib__message.html#gad0c12436c81e9c229e7bcd2d3801cf51',1,'eye::tracker']]]
];
