var searchData=
[
  ['device_5fstate',['device_state',['../structeye_1_1_tracker_1_1_state.html#a91b0772d5af6bbdbf4055e6dce3b1ab3',1,'eye::Tracker::State']]]
];
