var searchData=
[
  ['fixationtime',['FixationTime',['../group__eyelib__gaze.html#gad98df527ad601931f9b5e84577001eab',1,'eye']]]
];
