var searchData=
[
  ['calib_5frating',['calib_rating',['../namespaceeye.html#af3f1fb6202db327ea6b9b5817e9bd43a',1,'eye::calib_rating(bool is_calibrated, float error_deg)'],['../namespaceeye.html#ab5456cf2e629e0a60d8dd5860ac0284d',1,'eye::calib_rating(bool is_calibrated, Calibration::Eyes&lt; float &gt; error_deg)']]],
  ['calib_5frating_5fnum',['calib_rating_num',['../namespaceeye.html#afee6e4166422d563ae9964792f4bb8d6',1,'eye']]],
  ['calib_5frating_5fstr',['calib_rating_str',['../namespaceeye.html#a49803617bf806ee380295a3f9aa054a9',1,'eye']]],
  ['calib_5fsample_5fstate',['calib_sample_state',['../namespaceeye.html#aece477a3b889ac44eb15d362281c96af',1,'eye']]],
  ['calibpointwidget',['CalibPointWidget',['../classeye_1_1window_1_1_calib_point_widget.html#ab4e8468eb44e2731a0b355bb9d53bcb4',1,'eye::window::CalibPointWidget::CalibPointWidget(int x_px, int y_px, utl::color_rgb const &amp;top, utl::color_rgb const &amp;left, utl::color_rgb const &amp;right)'],['../classeye_1_1window_1_1_calib_point_widget.html#a70696d8b0897ac8d77ff1e7d84ede90c',1,'eye::window::CalibPointWidget::CalibPointWidget(Calibration::Point const &amp;p)'],['../classeye_1_1window_1_1_calib_point_widget.html#a11cf7c7c68f5b41277de74080fd9d764',1,'eye::window::CalibPointWidget::CalibPointWidget()=default']]],
  ['calibrate',['calibrate',['../classeye_1_1_tracker.html#a537da68fc118823634c6aa286d6a9040',1,'eye::Tracker']]],
  ['caps_5flock',['caps_lock',['../structeye_1_1window_1_1_event_1_1_state_1_1_key.html#a2f0d8a7a201ccdd62e168aee1a4c0eea',1,'eye::window::Event::State::Key']]],
  ['category',['category',['../group__eyelib__message.html#ga4bfe9ce707806394a8517c2abbadfe15',1,'eye::tracker']]],
  ['centroid',['centroid',['../classeye_1_1_dispersion_threshold.html#af1e8925905ae23911f352cf79f287e1d',1,'eye::DispersionThreshold::centroid()'],['../classeye_1_1_velocity_threshold.html#a1608f55206bd08ca5e21bcd51ac5a564',1,'eye::VelocityThreshold::centroid()'],['../structeye_1_1_calibration_1_1_point.html#a4f24a5c03b03ee291af19d75de5bbc96',1,'eye::Calibration::Point::centroid()']]],
  ['clear',['clear',['../classeye_1_1_point_cluster.html#accc78f1964aae0d3ce1440fc7c35a0e7',1,'eye::PointCluster']]],
  ['clear_5ftargets',['clear_targets',['../classeye_1_1_window.html#aece87581893c8870e3fffa5d226dfd98',1,'eye::Window']]],
  ['clicks',['clicks',['../structeye_1_1window_1_1_event_1_1_mouse.html#a17024c276aff3dd48b60cb36c0b8adf4',1,'eye::window::Event::Mouse']]],
  ['count',['count',['../classeye_1_1_fixation.html#ad493813bab2e030fe7a0cc32b92c83e4',1,'eye::Fixation']]],
  ['csv',['csv',['../structeye_1_1_calibration.html#a099f20696188d210b9cfdb78ba373251',1,'eye::Calibration::csv()'],['../group__eyelib__gaze.html#ga03097eaa6bca4a00228999e5b74b70f8',1,'eye::csv(Gaze::Tracking const &amp;t)'],['../group__eyelib__gaze.html#gabe1400613d84cedc760f7b89c7f0cad9',1,'eye::csv(Gaze const &amp;g)']]],
  ['csv_5fheader',['csv_header',['../group__eyelib__gaze.html#ga1cb8ef0b9f8880cf4a4622573e2a8475',1,'eye::Gaze']]],
  ['csv_5fheader_3c_20gaze_3a_3atracking_20_3e',['csv_header&lt; Gaze::Tracking &gt;',['../group__eyelib__gaze.html#ga3d90f6d6f4f8db38d7bb763a3dd0cb88',1,'eye']]],
  ['ctrl',['ctrl',['../structeye_1_1window_1_1_event_1_1_state_1_1_key.html#ac3466d853e800fa994fa3b35fa1ec1a0',1,'eye::window::Event::State::Key']]]
];
