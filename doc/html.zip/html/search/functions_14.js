var searchData=
[
  ['window',['window',['../classeye_1_1_tracker.html#ac4ed9e28b03dcc1192dd1abd4acfcb87',1,'eye::Tracker::window(ColorRGB const &amp;background={149, 149, 149})'],['../classeye_1_1_tracker.html#a32954cabfc49d1e153b4adf1ad01c210',1,'eye::Tracker::window(Targets const &amp;points, TargetDuration const &amp;target_ms={500, 1000, 500}, ColorRGB const &amp;background={149, 149, 149})'],['../classeye_1_1_window.html#a53a39bd5dda487d82cab04c6d5136695',1,'eye::Window::Window(Tracker &amp;tracker, Screen const &amp;scr, std::string const &amp;title, ColorRGB const &amp;bg={149, 149, 149})'],['../classeye_1_1_window.html#a4be6ba5e23879f033f9daf73322cb4a1',1,'eye::Window::Window(Window const &amp;)=delete']]]
];
