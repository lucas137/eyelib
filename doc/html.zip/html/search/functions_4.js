var searchData=
[
  ['empty',['empty',['../classeye_1_1_point_cluster.html#a9d258c5cd516d38f831207668d8d344a',1,'eye::PointCluster']]],
  ['event',['Event',['../structeye_1_1window_1_1_event.html#ab1020723df234bc3653dbe87d5a87020',1,'eye::window::Event::Event()=default'],['../structeye_1_1window_1_1_event.html#a180a25aaaa705c3444afc50e5ed3d407',1,'eye::window::Event::Event(unsigned time_ms, int code)']]]
];
