var searchData=
[
  ['datalog',['DataLog',['../classeye_1_1_data_log.html#a706f91a0ff742394e8c66635b21e1c48',1,'eye::DataLog::DataLog(std::string const &amp;app_name)'],['../classeye_1_1_data_log.html#a2f37a6c4df5965bc45c7da3ba0dea88d',1,'eye::DataLog::DataLog(DataLog const &amp;)=delete']]],
  ['dispersion',['dispersion',['../classeye_1_1_dispersion_threshold.html#af42558ccd8cef1091a6ba936d03df069',1,'eye::DispersionThreshold']]],
  ['dispersionthreshold',['DispersionThreshold',['../classeye_1_1_dispersion_threshold.html#afb0fc0dd10efe1dbb3afa83033ee3a80',1,'eye::DispersionThreshold']]],
  ['displacement',['displacement',['../classeye_1_1_velocity_threshold.html#a64ccc8946c80d9e5e441b3bd00c698f3',1,'eye::VelocityThreshold']]],
  ['distance_5fsq',['distance_sq',['../classeye_1_1_saccade_distance.html#af8fd94752c83b1a34eadcfe214c20192',1,'eye::SaccadeDistance']]],
  ['draw',['draw',['../classeye_1_1window_1_1_calib_point_widget.html#ad8bf6d6cba2eb8db9c19c6b88c37342b',1,'eye::window::CalibPointWidget::draw()'],['../classeye_1_1window_1_1_calib_widget.html#a95d09eac9d9b935c5b106b36e3ba1b5b',1,'eye::window::CalibWidget::draw()'],['../structeye_1_1window_1_1_gaze_widget.html#a9566da5c3c82ac4d197c7344c8d6f387',1,'eye::window::GazeWidget::draw()'],['../structeye_1_1window_1_1_target_widget.html#a10e30a70f6139166f858e0552be2ddab',1,'eye::window::TargetWidget::draw()'],['../structeye_1_1window_1_1_text_widget.html#ab216ae118ba95b69c09ee04b71c478e9',1,'eye::window::TextWidget::draw()']]],
  ['duration',['duration',['../classeye_1_1_fixation.html#abe8f0df9eaf034b7429b6df54d5c4514',1,'eye::Fixation::duration()'],['../classeye_1_1_time_metrics.html#ae8a751a21f5ed350462fb78168e8e4a3',1,'eye::TimeMetrics::duration()'],['../classeye_1_1_point_cluster.html#adcd00e0489270604441eb8e543b52f4b',1,'eye::PointCluster::duration()']]]
];
