var searchData=
[
  ['distance_5fvalues',['distance_values',['../classeye_1_1_saccade_distance.html#a1a4ddac7e3b109f3916feb32e4c481e7',1,'eye::SaccadeDistance']]],
  ['duration_5fvalues',['duration_values',['../classeye_1_1_time_metrics.html#ac2435365e51f92c0b7d373f44b66233b',1,'eye::TimeMetrics']]]
];
