var searchData=
[
  ['w_5fm',['w_m',['../structeye_1_1_screen.html#af0ca6b71147df74a989d9d3bebe5a16e',1,'eye::Screen']]],
  ['w_5fpx',['w_px',['../structeye_1_1_screen.html#a258a24a9be03a5a9e61f4fb05bcc4870',1,'eye::Screen']]]
];
