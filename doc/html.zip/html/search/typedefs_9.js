var searchData=
[
  ['size_5fvalues',['size_values',['../classeye_1_1_pupillometry.html#a10e415473d9964306b94031283bacee4',1,'eye::Pupillometry']]],
  ['state_5fhandler',['state_handler',['../classeye_1_1_tracker.html#a0c404723d41e5bc1ccbce30a9333269d',1,'eye::Tracker::state_handler()'],['../classeye_1_1_window.html#a3826a6fcf3fea3e6f1319eba011cd935',1,'eye::Window::state_handler()']]]
];
