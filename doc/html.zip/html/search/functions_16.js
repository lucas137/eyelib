var searchData=
[
  ['y',['y',['../classeye_1_1_fixation.html#a33ffe107436c76edf836481218874308',1,'eye::Fixation']]],
  ['y_5fscreen',['y_screen',['../structeye_1_1window_1_1_event_1_1_state_1_1_mouse.html#aa0a6cd13f9fb79a88c153a2f76d88c4c',1,'eye::window::Event::State::Mouse']]],
  ['y_5fwindow',['y_window',['../structeye_1_1window_1_1_event_1_1_state_1_1_mouse.html#ad42b5efa13736569cc12be5f7cdff8a2',1,'eye::window::Event::State::Mouse']]]
];
