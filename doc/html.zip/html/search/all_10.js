var searchData=
[
  ['r',['r',['../structeye_1_1_color_r_g_b.html#a6e994d9c82f62d25e8e1f2c4ae108425',1,'eye::ColorRGB']]],
  ['rating',['Rating',['../structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3',1,'eye::Calibration']]],
  ['raw_5fpx',['raw_px',['../structeye_1_1_gaze.html#af7b8b760c402ed3a28f15fe54ed39d74',1,'eye::Gaze']]],
  ['raw_5fx',['raw_x',['../structeye_1_1window_1_1_gaze_widget.html#a1e478b129f2e82115859ff286cd24e55',1,'eye::window::GazeWidget']]],
  ['raw_5fy',['raw_y',['../structeye_1_1window_1_1_gaze_widget.html#aa348ad3f11c0d131ae10d9c23d80dc74',1,'eye::window::GazeWidget']]],
  ['ready',['ready',['../classeye_1_1_window.html#ac15c67a5c5ce34b23c6aad3c0e63a4f4ab2fdab230a2c39f3595a947861863cb7',1,'eye::Window']]],
  ['recalibrate',['recalibrate',['../structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a02be20b0669fe1813c6c95fa0b68bbbe',1,'eye::Calibration']]],
  ['redraw',['redraw',['../classeye_1_1_window.html#a5a9d1cac3f42107050e2cfb2bbe27aee',1,'eye::Window']]],
  ['register_5fhandler',['register_handler',['../classeye_1_1_tracker.html#ae2620ccceb0fb471c0f8778fe75d1cb7',1,'eye::Tracker::register_handler(calib_handler callback)'],['../classeye_1_1_tracker.html#a5444ab7d72cb349468509a145d1d89d3',1,'eye::Tracker::register_handler(gaze_handler callback)'],['../classeye_1_1_tracker.html#ae2731146a5c632bc860949cad94bbb46',1,'eye::Tracker::register_handler(state_handler callback)'],['../classeye_1_1_window.html#a3c67110da5e559e32efe50d056f57e80',1,'eye::Window::register_handler(event_handler callback)'],['../classeye_1_1_window.html#ae182ec843b2a93d297d3057920f8163d',1,'eye::Window::register_handler(state_handler callback)']]],
  ['register_5fwindow',['register_window',['../classeye_1_1_gaze_target.html#a4f29ea64a62619c087201573b61aa70f',1,'eye::GazeTarget']]],
  ['request',['Request',['../classeye_1_1tracker_1_1_message.html#a60f7ab2615b2a55b8c8c5a7469c1b7f7',1,'eye::tracker::Message::Request()'],['../classeye_1_1tracker_1_1_message.html#a39713e53515b582d3103f5d1a18b4ddd',1,'eye::tracker::Message::request()'],['../group__eyelib__message.html#ga58676aed615d5246855bb3c382eb8df8',1,'eye::tracker::request()']]],
  ['resample',['resample',['../structeye_1_1_calibration_1_1_point.html#a98ae2295452d318bc30710e368ea2f9eaff8c32516924d7b42b74656c4847be05',1,'eye::Calibration::Point']]],
  ['reset',['reset',['../classeye_1_1_gaze_target.html#a2153e3798e751c178e330d5994c589fd',1,'eye::GazeTarget']]],
  ['right',['right',['../structeye_1_1window_1_1_event_1_1_key.html#a13d3516e24998563c23a78fd03b7607ca7c4f29407893c334a6cb7a87bf045c0d',1,'eye::window::Event::Key']]],
  ['right_5feye',['right_eye',['../structeye_1_1_calibration_1_1_eyes.html#ab8004c49f3c7fa4b654a9dde9c7cfc10',1,'eye::Calibration::Eyes']]],
  ['run',['run',['../classeye_1_1_data_log.html#ad46317805e21c2b73dd23673d94bb01f',1,'eye::DataLog::run()'],['../classeye_1_1_window.html#acb3dfa348653ebbf0c1580bbdc554544',1,'eye::Window::run()']]]
];
