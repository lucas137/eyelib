var indexSectionsWithContent =
{
  0: "abcdefghijklmnoprstuvwxy~",
  1: "cdefgkmpstvw",
  2: "e",
  3: "cdefgmpstvw",
  4: "abcdefghiklmnoprstuvwxy~",
  5: "abcdefghijklmnprstuvwxy",
  6: "bcdefghipst",
  7: "bcdrs",
  8: "abcdefghiklmnoprstu",
  9: "cegstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Modules"
};

