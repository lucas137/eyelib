var searchData=
[
  ['redraw',['redraw',['../classeye_1_1_window.html#a5a9d1cac3f42107050e2cfb2bbe27aee',1,'eye::Window']]],
  ['register_5fhandler',['register_handler',['../classeye_1_1_tracker.html#ae2620ccceb0fb471c0f8778fe75d1cb7',1,'eye::Tracker::register_handler(calib_handler callback)'],['../classeye_1_1_tracker.html#a5444ab7d72cb349468509a145d1d89d3',1,'eye::Tracker::register_handler(gaze_handler callback)'],['../classeye_1_1_tracker.html#ae2731146a5c632bc860949cad94bbb46',1,'eye::Tracker::register_handler(state_handler callback)'],['../classeye_1_1_window.html#a3c67110da5e559e32efe50d056f57e80',1,'eye::Window::register_handler(event_handler callback)'],['../classeye_1_1_window.html#ae182ec843b2a93d297d3057920f8163d',1,'eye::Window::register_handler(state_handler callback)']]],
  ['register_5fwindow',['register_window',['../classeye_1_1_gaze_target.html#a4f29ea64a62619c087201573b61aa70f',1,'eye::GazeTarget']]],
  ['request',['request',['../group__eyelib__message.html#ga58676aed615d5246855bb3c382eb8df8',1,'eye::tracker']]],
  ['reset',['reset',['../classeye_1_1_gaze_target.html#a2153e3798e751c178e330d5994c589fd',1,'eye::GazeTarget']]],
  ['run',['run',['../classeye_1_1_data_log.html#ad46317805e21c2b73dd23673d94bb01f',1,'eye::DataLog::run()'],['../classeye_1_1_window.html#acb3dfa348653ebbf0c1580bbdc554544',1,'eye::Window::run()']]]
];
