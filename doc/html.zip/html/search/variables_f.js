var searchData=
[
  ['r',['r',['../structeye_1_1_color_r_g_b.html#a6e994d9c82f62d25e8e1f2c4ae108425',1,'eye::ColorRGB']]],
  ['raw_5fpx',['raw_px',['../structeye_1_1_gaze.html#af7b8b760c402ed3a28f15fe54ed39d74',1,'eye::Gaze']]],
  ['raw_5fx',['raw_x',['../structeye_1_1window_1_1_gaze_widget.html#a1e478b129f2e82115859ff286cd24e55',1,'eye::window::GazeWidget']]],
  ['raw_5fy',['raw_y',['../structeye_1_1window_1_1_gaze_widget.html#aa348ad3f11c0d131ae10d9c23d80dc74',1,'eye::window::GazeWidget']]],
  ['request',['request',['../classeye_1_1tracker_1_1_message.html#a39713e53515b582d3103f5d1a18b4ddd',1,'eye::tracker::Message']]],
  ['right_5feye',['right_eye',['../structeye_1_1_calibration_1_1_eyes.html#ab8004c49f3c7fa4b654a9dde9c7cfc10',1,'eye::Calibration::Eyes']]]
];
