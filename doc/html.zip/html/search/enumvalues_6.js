var searchData=
[
  ['good',['good',['../structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a755f85c2723bb39381c7379a604160d8',1,'eye::Calibration']]],
  ['great',['great',['../structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3aacaa16770db76c1ffb9cee51c3cabfcf',1,'eye::Calibration']]]
];
