var searchData=
[
  ['gaze',['gaze',['../classeye_1_1_fixation.html#a0cf123f4dd97a26799b27c70608b47ae',1,'eye::Fixation::gaze()'],['../structeye_1_1_gaze.html#ac6da332904a2dec1316d67a5e8d77e28',1,'eye::Gaze::Gaze(std::string const &amp;timestamp, unsigned time_ms, Tracking const &amp;tracking, bool fixation, PointXY&lt; float &gt; const &amp;raw_px, PointXY&lt; float &gt; const &amp;avg_px, Pupil const &amp;pupil_left, Pupil const &amp;pupil_right)'],['../structeye_1_1_gaze.html#a4eb5193b857e3e2a4b1035b2c3dca560',1,'eye::Gaze::Gaze()=default']]],
  ['gaze_5ftime_5fms',['gaze_time_ms',['../classeye_1_1_tracker.html#a764c40e2fd10ddbf592b4076cc6bcbec',1,'eye::Tracker']]],
  ['gazetarget',['GazeTarget',['../classeye_1_1_gaze_target.html#af3e2ae86851d1ab5966557e63580f6ce',1,'eye::GazeTarget']]],
  ['gazewidget',['GazeWidget',['../structeye_1_1window_1_1_gaze_widget.html#a061b313d6735751dba9a5e1f36439d83',1,'eye::window::GazeWidget::GazeWidget(eye::Gaze const &amp;g)'],['../structeye_1_1window_1_1_gaze_widget.html#a6bfca364e121454956ad7017a20ba2c5',1,'eye::window::GazeWidget::GazeWidget()=default']]],
  ['get_5fcalib_5fhandler',['get_calib_handler',['../classeye_1_1_tracker.html#a5acfaf3c512544d2460ce29ce291118f',1,'eye::Tracker']]],
  ['get_5fgaze_5fhandler',['get_gaze_handler',['../classeye_1_1_tracker.html#a50444c62371c3fc7bcd6e5a5563ca0d2',1,'eye::Tracker']]],
  ['get_5fstate_5fhandler',['get_state_handler',['../classeye_1_1_tracker.html#a8bbc56bb66084ebf348bdc0ef50f3eef',1,'eye::Tracker']]],
  ['get_5ftarget',['get_target',['../classeye_1_1_gaze_target.html#abfac6e2c85e75798dd1d94114b77e7ad',1,'eye::GazeTarget']]]
];
