var searchData=
[
  ['time_5fms',['time_ms',['../structeye_1_1_gaze.html#a0a075aa84120ec4e2ae7c795e14fb94e',1,'eye::Gaze::time_ms()'],['../structeye_1_1window_1_1_event.html#af65a805beb48227b4e067a6822be86c8',1,'eye::window::Event::time_ms()']]],
  ['timestamp',['timestamp',['../structeye_1_1_gaze.html#a65fdb9b004df75d33a79e725867abb6e',1,'eye::Gaze']]],
  ['tracking',['tracking',['../structeye_1_1_gaze.html#affa5fef8ce218f05ed262f6c8a846845',1,'eye::Gaze']]]
];
