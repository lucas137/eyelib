var searchData=
[
  ['fail',['fail',['../structeye_1_1_gaze_1_1_tracking.html#ae518369aa1bc0e7a51f2a33766c30ccb',1,'eye::Gaze::Tracking']]],
  ['fixation',['fixation',['../structeye_1_1_gaze.html#a5252e06be034a0c671456734852eea26',1,'eye::Gaze::fixation()'],['../structeye_1_1window_1_1_gaze_widget.html#ab459b599d5fb4a278083016608bc347e',1,'eye::window::GazeWidget::fixation()']]],
  ['frame_5frate',['frame_rate',['../structeye_1_1_tracker_1_1_state.html#a7cac030d6545bd04ad6fb3747408ad9f',1,'eye::Tracker::State']]]
];
