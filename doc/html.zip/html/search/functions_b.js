var searchData=
[
  ['mean_5fx',['mean_x',['../classeye_1_1_point_cluster.html#abb6f4189f93cd85922be85c1efbcbb50',1,'eye::PointCluster']]],
  ['mean_5fy',['mean_y',['../classeye_1_1_point_cluster.html#ad9874b62ce67e10aea4c2d07ac074fcd',1,'eye::PointCluster']]],
  ['mouse',['Mouse',['../structeye_1_1window_1_1_event_1_1_mouse.html#a7a9cc8831d9ada579f4c6bec748d50d6',1,'eye::window::Event::Mouse']]]
];
