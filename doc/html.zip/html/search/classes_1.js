var searchData=
[
  ['datalog',['DataLog',['../classeye_1_1_data_log.html',1,'eye']]],
  ['dispersionthreshold',['DispersionThreshold',['../classeye_1_1_dispersion_threshold.html',1,'eye']]]
];
