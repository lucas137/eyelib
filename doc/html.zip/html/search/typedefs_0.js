var searchData=
[
  ['blinktime',['BlinkTime',['../group__eyelib__gaze.html#gab62d15adde0465d49d41215972970656',1,'eye']]]
];
