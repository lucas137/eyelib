var searchData=
[
  ['points',['points',['../structeye_1_1_calibration.html#abaddb18840f4ce225b73a2b5ad08ace7',1,'eye::Calibration']]],
  ['pupil_5fleft',['pupil_left',['../structeye_1_1_gaze.html#ad3e4c98186b98b0dd5b55c4948f283b0',1,'eye::Gaze']]],
  ['pupil_5fright',['pupil_right',['../structeye_1_1_gaze.html#ac43704ddf9205ee8e22df50945a7b0d9',1,'eye::Gaze']]]
];
