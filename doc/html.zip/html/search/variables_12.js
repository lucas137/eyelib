var searchData=
[
  ['user',['user',['../structeye_1_1_gaze_1_1_tracking.html#a89dfbae3234b9e34bf00d34979de582f',1,'eye::Gaze::Tracking']]]
];
