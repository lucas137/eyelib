var searchData=
[
  ['g',['g',['../structeye_1_1_color_r_g_b.html#a30a415f417ec25296e9e51a8e6c1fa43',1,'eye::ColorRGB']]],
  ['gaze',['gaze',['../structeye_1_1_gaze_1_1_tracking.html#af44c0884c0f30272efa4af78dfff80a0',1,'eye::Gaze::Tracking']]]
];
