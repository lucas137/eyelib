var searchData=
[
  ['mean_5ferror_5fpx',['mean_error_px',['../structeye_1_1_calibration_1_1_point.html#ae48b1ae6f937c81838ce2af2807d8249',1,'eye::Calibration::Point']]],
  ['mouse',['mouse',['../structeye_1_1window_1_1_event.html#aba6727cf44d63706979e60785d7a967d',1,'eye::window::Event']]]
];
