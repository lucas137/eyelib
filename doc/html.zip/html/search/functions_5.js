var searchData=
[
  ['fixation',['fixation',['../classeye_1_1_dispersion_threshold.html#a44aabdc2460396be7c0783b65fc5a6e0',1,'eye::DispersionThreshold::fixation()'],['../classeye_1_1_velocity_threshold.html#a31f7d001954004ef27df3c02b666bee2',1,'eye::VelocityThreshold::fixation()'],['../classeye_1_1_fixation.html#a40ad0e1ed7e8089d7761b374e3aec33e',1,'eye::Fixation::Fixation()']]],
  ['function',['function',['../structeye_1_1window_1_1_event_1_1_key.html#ae473626c1cfbc397f8524f0c64f90bf2',1,'eye::window::Event::Key']]]
];
