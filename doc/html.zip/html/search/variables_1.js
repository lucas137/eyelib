var searchData=
[
  ['b',['b',['../structeye_1_1_color_r_g_b.html#a0f142f6f02f3d91c8a7019a4014e2672',1,'eye::ColorRGB']]],
  ['before_5fms',['before_ms',['../structeye_1_1_target_duration.html#a8e24a0051a7d590ddf3bf60deb4706fe',1,'eye::TargetDuration']]],
  ['binocular',['binocular',['../structeye_1_1_calibration_1_1_eyes.html#a822cd0e6c3969e2c019f4496f00237a9',1,'eye::Calibration::Eyes']]],
  ['bits',['bits',['../structeye_1_1_gaze_1_1_tracking.html#ace3a372f1c8bef39985abbf3ab0e6c37',1,'eye::Gaze::Tracking']]]
];
