var searchData=
[
  ['index',['index',['../structeye_1_1_screen.html#a7e536ffb2f289101a34cf97ccde3dedb',1,'eye::Screen']]],
  ['is_5fcalibrated',['is_calibrated',['../structeye_1_1_tracker_1_1_state.html#a2a4e0a0ccc50b6bc600f0b6e32103e90',1,'eye::Tracker::State']]],
  ['is_5fcalibrating',['is_calibrating',['../structeye_1_1_tracker_1_1_state.html#a8d389d181584af418566849e3884ff6a',1,'eye::Tracker::State']]],
  ['is_5fconnected',['is_connected',['../structeye_1_1_tracker_1_1_state.html#a18b0708c51d916ec7224717d6d310023',1,'eye::Tracker::State']]],
  ['is_5fstarted',['is_started',['../structeye_1_1_tracker_1_1_state.html#a4585cb805599f8350e42a321af4b093e',1,'eye::Tracker::State']]]
];
