var searchData=
[
  ['ready',['ready',['../classeye_1_1_window.html#ac15c67a5c5ce34b23c6aad3c0e63a4f4ab2fdab230a2c39f3595a947861863cb7',1,'eye::Window']]],
  ['recalibrate',['recalibrate',['../structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a02be20b0669fe1813c6c95fa0b68bbbe',1,'eye::Calibration']]],
  ['resample',['resample',['../structeye_1_1_calibration_1_1_point.html#a98ae2295452d318bc30710e368ea2f9eaff8c32516924d7b42b74656c4847be05',1,'eye::Calibration::Point']]],
  ['right',['right',['../structeye_1_1window_1_1_event_1_1_key.html#a13d3516e24998563c23a78fd03b7607ca7c4f29407893c334a6cb7a87bf045c0d',1,'eye::window::Event::Key']]]
];
