var searchData=
[
  ['saccadedistance',['SaccadeDistance',['../classeye_1_1_saccade_distance.html',1,'eye']]],
  ['screen',['Screen',['../structeye_1_1_screen.html',1,'eye']]],
  ['state',['State',['../structeye_1_1window_1_1_event_1_1_state.html',1,'eye::window::Event']]],
  ['state',['State',['../structeye_1_1_tracker_1_1_state.html',1,'eye::Tracker']]]
];
