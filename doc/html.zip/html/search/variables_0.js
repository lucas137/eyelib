var searchData=
[
  ['accuracy_5fdeg',['accuracy_deg',['../structeye_1_1_calibration_1_1_point.html#a05bb3cde2d67cb8d87c914557751698f',1,'eye::Calibration::Point']]],
  ['accuracy_5frating',['accuracy_rating',['../structeye_1_1_calibration_1_1_point.html#a4176cae0cacc8e8026d40c72f60e5d3c',1,'eye::Calibration::Point']]],
  ['active',['active',['../structeye_1_1_target.html#a677848aac56bc18187cc5c6ada382973',1,'eye::Target']]],
  ['active_5fms',['active_ms',['../structeye_1_1_target_duration.html#aa8abf0a562482fb9c0b3ebfef4689360',1,'eye::TargetDuration']]],
  ['after_5fms',['after_ms',['../structeye_1_1_target_duration.html#a4bbb51c538ed6a336aaab641e85e6a77',1,'eye::TargetDuration']]],
  ['avg_5fpx',['avg_px',['../structeye_1_1_gaze.html#aad6e7b9af8c74166970c9ac5839e8838',1,'eye::Gaze']]],
  ['avg_5fstd_5fdev_5fpx',['avg_std_dev_px',['../structeye_1_1_calibration_1_1_point.html#a21f6d0d8a0f36bae8d332bf59109c74f',1,'eye::Calibration::Point']]],
  ['avg_5fx',['avg_x',['../structeye_1_1window_1_1_gaze_widget.html#a397681da7ec37cc654f33dee3809cc24',1,'eye::window::GazeWidget']]],
  ['avg_5fy',['avg_y',['../structeye_1_1window_1_1_gaze_widget.html#a201aec41125bd2b0b701d0bdbe809fd2',1,'eye::window::GazeWidget']]]
];
