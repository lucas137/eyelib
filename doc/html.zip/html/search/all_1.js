var searchData=
[
  ['b',['b',['../structeye_1_1_color_r_g_b.html#a0f142f6f02f3d91c8a7019a4014e2672',1,'eye::ColorRGB']]],
  ['backspace',['backspace',['../structeye_1_1window_1_1_event_1_1_key.html#a13d3516e24998563c23a78fd03b7607ca5528770f4bce9c9b0ce9bbb8645aef45',1,'eye::window::Event::Key']]],
  ['bad_5ffirmware',['bad_firmware',['../classeye_1_1_tracker.html#ae7b2fc42cc84050396fdc44841142889a2f91131e6b36ccda33ccc333cbaed9ee',1,'eye::Tracker']]],
  ['bad_5frequest',['bad_request',['../classeye_1_1tracker_1_1_message.html#ac0bf852b46252097390ae43e12f0e703a373d9e6e1aaf30e691dadb57eb22d7b1',1,'eye::tracker::Message']]],
  ['before_5fms',['before_ms',['../structeye_1_1_target_duration.html#a8e24a0051a7d590ddf3bf60deb4706fe',1,'eye::TargetDuration']]],
  ['binocular',['binocular',['../structeye_1_1_calibration_1_1_eyes.html#a822cd0e6c3969e2c019f4496f00237a9',1,'eye::Calibration::Eyes']]],
  ['bits',['bits',['../structeye_1_1_gaze_1_1_tracking.html#ace3a372f1c8bef39985abbf3ab0e6c37',1,'eye::Gaze::Tracking']]],
  ['blinktime',['BlinkTime',['../group__eyelib__gaze.html#gab62d15adde0465d49d41215972970656',1,'eye']]],
  ['button',['Button',['../structeye_1_1window_1_1_event_1_1_mouse.html#afd120a4d97a2ec74f815195745aa33ae',1,'eye::window::Event::Mouse::Button()'],['../structeye_1_1window_1_1_event_1_1_mouse.html#a7e711089d1532e362e6a4443d147f406',1,'eye::window::Event::Mouse::button()'],['../structeye_1_1window_1_1_event_1_1_key.html#a13d3516e24998563c23a78fd03b7607cace50a09343724eb82df11390e2c1de18',1,'eye::window::Event::Key::button()']]],
  ['button_5fleft',['button_left',['../structeye_1_1window_1_1_event_1_1_state_1_1_mouse.html#a625e39788d8d5d4e11a4986a14247700',1,'eye::window::Event::State::Mouse']]],
  ['button_5fmiddle',['button_middle',['../structeye_1_1window_1_1_event_1_1_state_1_1_mouse.html#a71944390236ec6bc8a838b7d5fa051f2',1,'eye::window::Event::State::Mouse']]],
  ['button_5fright',['button_right',['../structeye_1_1window_1_1_event_1_1_state_1_1_mouse.html#a6564f9cefe2ee80630c0d503e0e19c31',1,'eye::window::Event::State::Mouse']]]
];
