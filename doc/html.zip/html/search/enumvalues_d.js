var searchData=
[
  ['ok',['ok',['../structeye_1_1_calibration_1_1_point.html#a98ae2295452d318bc30710e368ea2f9ea444bcb3a3fcf8389296c49467f27e1d6',1,'eye::Calibration::Point::ok()'],['../classeye_1_1tracker_1_1_message.html#ac0bf852b46252097390ae43e12f0e703a444bcb3a3fcf8389296c49467f27e1d6',1,'eye::tracker::Message::ok()']]]
];
