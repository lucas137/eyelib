var searchData=
[
  ['screen_5fchange',['screen_change',['../classeye_1_1tracker_1_1_message.html#ac0bf852b46252097390ae43e12f0e703a57ab9f776a02e806f43e6422b3d99f8b',1,'eye::tracker::Message']]],
  ['scroll_5flock',['scroll_lock',['../structeye_1_1window_1_1_event_1_1_key.html#a13d3516e24998563c23a78fd03b7607ca52752d17cb8e9c551c3a736c45e1ddf1',1,'eye::window::Event::Key']]],
  ['server_5ferror',['server_error',['../classeye_1_1tracker_1_1_message.html#ac0bf852b46252097390ae43e12f0e703a0317120d5eccfe09a241439b7dc3af2c',1,'eye::tracker::Message']]],
  ['shift_5fleft',['shift_left',['../structeye_1_1window_1_1_event_1_1_key.html#a13d3516e24998563c23a78fd03b7607cabc9e94a9606c06cd9d0dcff07b6148ec',1,'eye::window::Event::Key']]],
  ['shift_5fright',['shift_right',['../structeye_1_1window_1_1_event_1_1_key.html#a13d3516e24998563c23a78fd03b7607ca066380d27185d48e0c5e3c5a521a8e1d',1,'eye::window::Event::Key']]]
];
