var group__eyelib =
[
    [ "calib", "group__eyelib__calib.html", "group__eyelib__calib" ],
    [ "gaze", "group__eyelib__gaze.html", "group__eyelib__gaze" ],
    [ "screen", "group__eyelib__screen.html", "group__eyelib__screen" ],
    [ "tracker", "group__eyelib__tracker.html", "group__eyelib__tracker" ]
];