var structeye_1_1window_1_1_text_line =
[
    [ "TextLine", "structeye_1_1window_1_1_text_line.html#a7b16482a5fa3c2a08bdf7fdb6af270b3", null ],
    [ "TextLine", "structeye_1_1window_1_1_text_line.html#a430bb84e4b25f81c8fcc945abcb2f9a3", null ],
    [ "str", "structeye_1_1window_1_1_text_line.html#ab6d65c72d65a562d8575220878f20186", null ],
    [ "x_px", "structeye_1_1window_1_1_text_line.html#a8e75f78ad44c8111435e5084db31c054", null ],
    [ "y_px", "structeye_1_1window_1_1_text_line.html#ac7f7f13bcd9db019daaeaceb6a4a4b22", null ]
];