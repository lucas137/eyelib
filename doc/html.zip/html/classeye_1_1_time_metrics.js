var classeye_1_1_time_metrics =
[
    [ "duration_values", "classeye_1_1_time_metrics.html#ac2435365e51f92c0b7d373f44b66233b", null ],
    [ "interval_values", "classeye_1_1_time_metrics.html#a7e67d982bc0ae9d78ccbb7a30b7e1b56", null ],
    [ "duration", "classeye_1_1_time_metrics.html#ae8a751a21f5ed350462fb78168e8e4a3", null ],
    [ "interval", "classeye_1_1_time_metrics.html#afb2742663a9a898d53035ca1ac06aef5", null ],
    [ "update", "classeye_1_1_time_metrics.html#a8b6538514029c223a5345e8a3eeba0b0", null ]
];