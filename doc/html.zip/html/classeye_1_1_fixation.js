var classeye_1_1_fixation =
[
    [ "Fixation", "classeye_1_1_fixation.html#a40ad0e1ed7e8089d7761b374e3aec33e", null ],
    [ "count", "classeye_1_1_fixation.html#ad493813bab2e030fe7a0cc32b92c83e4", null ],
    [ "duration", "classeye_1_1_fixation.html#abe8f0df9eaf034b7429b6df54d5c4514", null ],
    [ "gaze", "classeye_1_1_fixation.html#a0cf123f4dd97a26799b27c70608b47ae", null ],
    [ "interval", "classeye_1_1_fixation.html#a3effd15a0def8a958ac048544bdad36b", null ],
    [ "is_fixated", "classeye_1_1_fixation.html#a96b5dcb24505b6b5d2ea88d4c5fc15c5", null ],
    [ "position", "classeye_1_1_fixation.html#a70d5bcf2d12544e3ea13d0db4fdd6937", null ],
    [ "x", "classeye_1_1_fixation.html#a075562a38fa1a48041030dfd34405407", null ],
    [ "y", "classeye_1_1_fixation.html#a33ffe107436c76edf836481218874308", null ]
];