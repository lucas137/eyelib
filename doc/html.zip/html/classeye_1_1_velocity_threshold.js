var classeye_1_1_velocity_threshold =
[
    [ "VelocityThreshold", "classeye_1_1_velocity_threshold.html#ad455bd18ae3fb34ba561898060f18c8c", null ],
    [ "centroid", "classeye_1_1_velocity_threshold.html#a1608f55206bd08ca5e21bcd51ac5a564", null ],
    [ "displacement", "classeye_1_1_velocity_threshold.html#a64ccc8946c80d9e5e441b3bd00c698f3", null ],
    [ "fixation", "classeye_1_1_velocity_threshold.html#a31f7d001954004ef27df3c02b666bee2", null ]
];