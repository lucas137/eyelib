var group__eyelib__calib =
[
    [ "Eyes", "structeye_1_1_calibration_1_1_eyes.html", [
      [ "binocular", "structeye_1_1_calibration_1_1_eyes.html#a822cd0e6c3969e2c019f4496f00237a9", null ],
      [ "left_eye", "structeye_1_1_calibration_1_1_eyes.html#a72f027974e4a25245c2c999f569ebf9e", null ],
      [ "right_eye", "structeye_1_1_calibration_1_1_eyes.html#ab8004c49f3c7fa4b654a9dde9c7cfc10", null ]
    ] ],
    [ "Point", "structeye_1_1_calibration_1_1_point.html", [
      [ "State", "structeye_1_1_calibration_1_1_point.html#a98ae2295452d318bc30710e368ea2f9e", [
        [ "no_data", "structeye_1_1_calibration_1_1_point.html#a98ae2295452d318bc30710e368ea2f9ea56a54c7029e3420c4490f842f1997d5a", null ],
        [ "resample", "structeye_1_1_calibration_1_1_point.html#a98ae2295452d318bc30710e368ea2f9eaff8c32516924d7b42b74656c4847be05", null ],
        [ "ok", "structeye_1_1_calibration_1_1_point.html#a98ae2295452d318bc30710e368ea2f9ea444bcb3a3fcf8389296c49467f27e1d6", null ],
        [ "error", "structeye_1_1_calibration_1_1_point.html#a98ae2295452d318bc30710e368ea2f9eacb5e100e5a9a3e7f6d1fd97512215282", null ]
      ] ],
      [ "centroid", "structeye_1_1_calibration_1_1_point.html#a4f24a5c03b03ee291af19d75de5bbc96", null ],
      [ "accuracy_deg", "structeye_1_1_calibration_1_1_point.html#a05bb3cde2d67cb8d87c914557751698f", null ],
      [ "accuracy_rating", "structeye_1_1_calibration_1_1_point.html#a4176cae0cacc8e8026d40c72f60e5d3c", null ],
      [ "avg_std_dev_px", "structeye_1_1_calibration_1_1_point.html#a21f6d0d8a0f36bae8d332bf59109c74f", null ],
      [ "calibrate_px", "structeye_1_1_calibration_1_1_point.html#a1c259881944c59289d5fc48d06c59e0f", null ],
      [ "estimated_px", "structeye_1_1_calibration_1_1_point.html#a2ef95b34e554e2322c011f9adf77285c", null ],
      [ "mean_error_px", "structeye_1_1_calibration_1_1_point.html#ae48b1ae6f937c81838ce2af2807d8249", null ],
      [ "sample_state", "structeye_1_1_calibration_1_1_point.html#ab6a8f07860c6e98cf8f60be19d04b4cd", null ]
    ] ],
    [ "Calibration", "structeye_1_1_calibration.html", [
      [ "Points", "structeye_1_1_calibration.html#a793d541d8586900d35db984aacbc0145", null ],
      [ "Rating", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3", [
        [ "uncalibrated", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a4dd2c45d0236af4121ae4f2986671a20", null ],
        [ "recalibrate", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a02be20b0669fe1813c6c95fa0b68bbbe", null ],
        [ "poor", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a5cffaf9375c0ef1d49451b062abdac80", null ],
        [ "moderate", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a7f0217cdcdd58ba86aae84d9d3d79f81", null ],
        [ "good", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a755f85c2723bb39381c7379a604160d8", null ],
        [ "great", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3aacaa16770db76c1ffb9cee51c3cabfcf", null ]
      ] ],
      [ "csv", "structeye_1_1_calibration.html#a099f20696188d210b9cfdb78ba373251", null ],
      [ "operator<<", "structeye_1_1_calibration.html#ad115a75a20d9127a832686adab772936", null ],
      [ "to_string", "structeye_1_1_calibration.html#a503400db5da14858d2bed20ea4a0b945", null ],
      [ "error_deg", "structeye_1_1_calibration.html#a7c604be8ffb9083274ac59b94d46c525", null ],
      [ "error_rating", "structeye_1_1_calibration.html#ad9b0afc3650961b53e039f53e9410280", null ],
      [ "points", "structeye_1_1_calibration.html#abaddb18840f4ce225b73a2b5ad08ace7", null ],
      [ "success", "structeye_1_1_calibration.html#a633ab9ef9ad3bf4bb3ce4691fc3df628", null ]
    ] ]
];