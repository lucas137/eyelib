var classeye_1_1_pupillometry =
[
    [ "size_values", "classeye_1_1_pupillometry.html#a10e415473d9964306b94031283bacee4", null ],
    [ "pupil_size", "classeye_1_1_pupillometry.html#ab703a19ec3f1c6734cf45b55a2c8d94b", null ],
    [ "update", "classeye_1_1_pupillometry.html#a306e2b9a46919d9cf090f473aaf258d6", null ]
];