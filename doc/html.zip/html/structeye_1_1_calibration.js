var structeye_1_1_calibration =
[
    [ "Points", "structeye_1_1_calibration.html#a793d541d8586900d35db984aacbc0145", null ],
    [ "Rating", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3", [
      [ "uncalibrated", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a4dd2c45d0236af4121ae4f2986671a20", null ],
      [ "recalibrate", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a02be20b0669fe1813c6c95fa0b68bbbe", null ],
      [ "poor", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a5cffaf9375c0ef1d49451b062abdac80", null ],
      [ "moderate", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a7f0217cdcdd58ba86aae84d9d3d79f81", null ],
      [ "good", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3a755f85c2723bb39381c7379a604160d8", null ],
      [ "great", "structeye_1_1_calibration.html#a013457d327d679816ffbdf063e1a1af3aacaa16770db76c1ffb9cee51c3cabfcf", null ]
    ] ],
    [ "csv", "structeye_1_1_calibration.html#a099f20696188d210b9cfdb78ba373251", null ],
    [ "operator<<", "structeye_1_1_calibration.html#ad115a75a20d9127a832686adab772936", null ],
    [ "to_string", "structeye_1_1_calibration.html#a503400db5da14858d2bed20ea4a0b945", null ],
    [ "error_deg", "structeye_1_1_calibration.html#a7c604be8ffb9083274ac59b94d46c525", null ],
    [ "error_rating", "structeye_1_1_calibration.html#ad9b0afc3650961b53e039f53e9410280", null ],
    [ "points", "structeye_1_1_calibration.html#abaddb18840f4ce225b73a2b5ad08ace7", null ],
    [ "success", "structeye_1_1_calibration.html#a633ab9ef9ad3bf4bb3ce4691fc3df628", null ]
];