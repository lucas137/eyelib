var structeye_1_1_gaze =
[
    [ "Gaze", "structeye_1_1_gaze.html#ac6da332904a2dec1316d67a5e8d77e28", null ],
    [ "Gaze", "structeye_1_1_gaze.html#a4eb5193b857e3e2a4b1035b2c3dca560", null ],
    [ "csv_header", "group__eyelib__gaze.html#ga1cb8ef0b9f8880cf4a4622573e2a8475", null ],
    [ "operator<<", "group__eyelib__gaze.html#ga726a8bdb97cb306c8f0d33517cc726cf", null ],
    [ "avg_px", "structeye_1_1_gaze.html#aad6e7b9af8c74166970c9ac5839e8838", null ],
    [ "fixation", "structeye_1_1_gaze.html#a5252e06be034a0c671456734852eea26", null ],
    [ "pupil_left", "structeye_1_1_gaze.html#ad3e4c98186b98b0dd5b55c4948f283b0", null ],
    [ "pupil_right", "structeye_1_1_gaze.html#ac43704ddf9205ee8e22df50945a7b0d9", null ],
    [ "raw_px", "structeye_1_1_gaze.html#af7b8b760c402ed3a28f15fe54ed39d74", null ],
    [ "time_ms", "structeye_1_1_gaze.html#a0a075aa84120ec4e2ae7c795e14fb94e", null ],
    [ "timestamp", "structeye_1_1_gaze.html#a65fdb9b004df75d33a79e725867abb6e", null ],
    [ "tracking", "structeye_1_1_gaze.html#affa5fef8ce218f05ed262f6c8a846845", null ]
];