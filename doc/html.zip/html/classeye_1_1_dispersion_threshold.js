var classeye_1_1_dispersion_threshold =
[
    [ "DispersionThreshold", "classeye_1_1_dispersion_threshold.html#afb0fc0dd10efe1dbb3afa83033ee3a80", null ],
    [ "centroid", "classeye_1_1_dispersion_threshold.html#af1e8925905ae23911f352cf79f287e1d", null ],
    [ "dispersion", "classeye_1_1_dispersion_threshold.html#af42558ccd8cef1091a6ba936d03df069", null ],
    [ "fixation", "classeye_1_1_dispersion_threshold.html#a44aabdc2460396be7c0783b65fc5a6e0", null ]
];