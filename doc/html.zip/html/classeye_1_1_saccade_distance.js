var classeye_1_1_saccade_distance =
[
    [ "distance_values", "classeye_1_1_saccade_distance.html#a1a4ddac7e3b109f3916feb32e4c481e7", null ],
    [ "distance_sq", "classeye_1_1_saccade_distance.html#af8fd94752c83b1a34eadcfe214c20192", null ],
    [ "update", "classeye_1_1_saccade_distance.html#aba0010d7bb6187d1f848cb5e75cc29ca", null ]
];