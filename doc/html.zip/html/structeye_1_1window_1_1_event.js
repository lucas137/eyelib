var structeye_1_1window_1_1_event =
[
    [ "Event", "structeye_1_1window_1_1_event.html#ab1020723df234bc3653dbe87d5a87020", null ],
    [ "Event", "structeye_1_1window_1_1_event.html#a180a25aaaa705c3444afc50e5ed3d407", null ],
    [ "is_focus", "structeye_1_1window_1_1_event.html#ac81e15425709662a7bc1cb80b51a3165", null ],
    [ "is_key", "structeye_1_1window_1_1_event.html#aab64a445193182c002ce275e5a5261de", null ],
    [ "is_mouse", "structeye_1_1window_1_1_event.html#a69d2df714ea50c2e7f46add0bd37935c", null ],
    [ "code", "structeye_1_1window_1_1_event.html#ac314c3fc628f9672bbb48c5478f290c8", null ],
    [ "key", "structeye_1_1window_1_1_event.html#a6a1c18222944a149d548db1ea7abfec8", null ],
    [ "mouse", "structeye_1_1window_1_1_event.html#aba6727cf44d63706979e60785d7a967d", null ],
    [ "name", "structeye_1_1window_1_1_event.html#ab49d96d9bfdf77e77afdefeb4311bf9c", null ],
    [ "state", "structeye_1_1window_1_1_event.html#a1dbdbed06fcd9cddcf4ebf1a7650bcb9", null ],
    [ "time_ms", "structeye_1_1window_1_1_event.html#af65a805beb48227b4e067a6822be86c8", null ]
];