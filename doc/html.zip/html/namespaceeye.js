var namespaceeye =
[
    [ "tracker", null, [
      [ "Calibrator", "classeye_1_1tracker_1_1_calibrator.html", "classeye_1_1tracker_1_1_calibrator" ],
      [ "Message", "classeye_1_1tracker_1_1_message.html", "classeye_1_1tracker_1_1_message" ]
    ] ],
    [ "window", null, [
      [ "CalibPointWidget", "classeye_1_1window_1_1_calib_point_widget.html", "classeye_1_1window_1_1_calib_point_widget" ],
      [ "CalibWidget", "classeye_1_1window_1_1_calib_widget.html", "classeye_1_1window_1_1_calib_widget" ],
      [ "Event", "structeye_1_1window_1_1_event.html", "structeye_1_1window_1_1_event" ],
      [ "GazeWidget", "structeye_1_1window_1_1_gaze_widget.html", "structeye_1_1window_1_1_gaze_widget" ],
      [ "TargetWidget", "structeye_1_1window_1_1_target_widget.html", "structeye_1_1window_1_1_target_widget" ],
      [ "TextLine", "structeye_1_1window_1_1_text_line.html", "structeye_1_1window_1_1_text_line" ],
      [ "TextWidget", "structeye_1_1window_1_1_text_widget.html", "structeye_1_1window_1_1_text_widget" ]
    ] ],
    [ "Calibration", "structeye_1_1_calibration.html", "structeye_1_1_calibration" ],
    [ "ColorRGB", "structeye_1_1_color_r_g_b.html", "structeye_1_1_color_r_g_b" ],
    [ "DataLog", "classeye_1_1_data_log.html", "classeye_1_1_data_log" ],
    [ "DispersionThreshold", "classeye_1_1_dispersion_threshold.html", "classeye_1_1_dispersion_threshold" ],
    [ "Fixation", "classeye_1_1_fixation.html", "classeye_1_1_fixation" ],
    [ "Gaze", "structeye_1_1_gaze.html", "structeye_1_1_gaze" ],
    [ "GazeTarget", "classeye_1_1_gaze_target.html", "classeye_1_1_gaze_target" ],
    [ "PointCluster", "classeye_1_1_point_cluster.html", "classeye_1_1_point_cluster" ],
    [ "PointXY", "structeye_1_1_point_x_y.html", "structeye_1_1_point_x_y" ],
    [ "Pupillometry", "classeye_1_1_pupillometry.html", "classeye_1_1_pupillometry" ],
    [ "SaccadeDistance", "classeye_1_1_saccade_distance.html", "classeye_1_1_saccade_distance" ],
    [ "Screen", "structeye_1_1_screen.html", "structeye_1_1_screen" ],
    [ "Target", "structeye_1_1_target.html", "structeye_1_1_target" ],
    [ "TargetDuration", "structeye_1_1_target_duration.html", "structeye_1_1_target_duration" ],
    [ "TimeMetrics", "classeye_1_1_time_metrics.html", "classeye_1_1_time_metrics" ],
    [ "Tracker", "classeye_1_1_tracker.html", "classeye_1_1_tracker" ],
    [ "VelocityThreshold", "classeye_1_1_velocity_threshold.html", "classeye_1_1_velocity_threshold" ],
    [ "Window", "classeye_1_1_window.html", "classeye_1_1_window" ]
];